function echartDataToLaypage(data_info){

    var data_maxlength=0
    var return_info={}
    var data_maxindex=0
    var data_start=0;
    var select_page=data_info.select_page;
    var lay_page=data_info.lay_page;
    var series=data_info.echartsOptions.series
    var series_slice=$.extend(true, [], series)
    series.forEach((item,i)=>{
      //console.log(item,i)
      if(data_maxlength<item.data.length){
        data_maxlength=item.data.length
        data_maxindex=i;
      }
  
    })
    //console.log('series_slice',series_slice)
    lay_page.option.count=data_maxlength
    //console.log(lay_page)
    var remainder=lay_page.option.count%lay_page.option.limit//最后一页的数据个数
    var page_count=Math.ceil(lay_page.option.count/lay_page.option.limit)//总共有几页
  
    //console.log(remainder,page_count)
    if(page_count==lay_page.option.curr||lay_page.select_page==lay_page.option.curr||lay_page.select_page==-1)
    {
      var data_start=lay_page.option.count-remainder
      var data_end=lay_page.option.count
      //console.log('last page')
      return_info.curr=page_count
      lay_page.select_page=page_count
      lay_page.option.curr=page_count
    }
    else
    {
      
      var data_start=(lay_page.option.curr-1)*lay_page.option.limit
      var data_end=(lay_page.option.curr)*lay_page.option.limit
      //console.log('other page')
      return_info.curr=lay_page.option.curr
    }
    //console.log(data_maxlength,data_start,data_end,remainder)
    //if(data_maxlength>max_ref)
    {
      //data_start=data_maxlength-max_ref;
      series_slice.forEach((item,i)=>{
        item.data=item.data.slice(data_start,data_end);
      })
      //series=_this.echartsOptions.series.slice(_this.echartsOptions.series.length-max_ref);
      //console.log('series',series)
      //console.log('series_slice',series_slice)

      
    }
    return_info=Object.assign({}, return_info, {
      data_maxlength:data_maxlength,
      data_start:data_start,
      page_count:page_count,
      data_maxindex:data_maxindex,
      series_slice:series_slice,
  });
    return return_info
}
function jsonToCSV(jsonData){
 
  var str_head='\ufeff'
  var str_data=''
  var str_maxlength=0
  var data_total_lenght=0;
  console.log(jsonData)
  jsonData.forEach((item,i)=>{
    //console.log(item,i)
    str_head+=item.name+ '\t,'
    if(str_maxlength<item.data.length)str_maxlength=item.data.length
    data_total_lenght+=item.data.length

  })
  console.log('data_total_lenght',data_total_lenght)
  str_head+='\n'
for(let i = 0 ; i < str_maxlength; i++ ){
    jsonData.forEach((item)=>{
        //console.log(typeof(item.data[i]))
        if(typeof(item.data[i])=='number')
        {
            str_data+=`${item.data[i] + ''},`
        }
        else if(typeof(item.data[i])=='object')
        {
            str_data+=`${item.data[i][1]+''},`

        }
        else
        {
            str_data+=`${''},`

        }
    })
    str_data+='\n'
}
  return str_head+str_data
}
/**
 * Created by dell on 2019-08-03.
 */
function str2hexToDis(str) {
    if(str == ""){
        console.log('str2hexToDis str is null')
        return
    }
    var val = "";
    for(let i = 0; i < str.length; i++){
        if(val == "")
           val += str.charCodeAt(i).toString(16).toUpperCase() + ' ';
        else
           val += str.charCodeAt(i).toString(16).toUpperCase() + ' ';
    }
    //console.log('str2hexToDis',val)
    return val
}

function str2hex(str) {
    if(str == ""){
        console.log('str2hex str is null')
        return
    }
    var val = "";
    for(let i = 0; i < str.length; i++){
        if(val == "")
            val = str.charCodeAt(i).toString(16);
        else
            val += str.charCodeAt(i).toString(16).toUpperCase();
    }
    //转大写字母
    //val = val.toUpperCase()
    //console.log('str2hex',val)
    return val
}

function hex2strToDis(hex) {
    if(hex == "") {
        console.log("hex2strToDis hex is null")
        return
    }

    var val = "";
    var arr = hex.split(" ");
    //console.log('arr',arr)
    for(var i = 0; i < arr.length; i++){
        //console.log('string charcode',String.fromCharCode(parseInt(arr[i],16)))
        if(String.fromCharCode(parseInt(arr[i],16)) != null)
        {
            val += String.fromCharCode(parseInt(arr[i],16));
        }
    }
    //console.log("hex2strToDis",val)
    return val
}

function hex2array(hex) {
    if(hex == ""){
        console.log("hex2str hex is null")
        return
    }
    var val = new Array();
    var arr = hex.split(" ");
    //console.log('arr',arr)
    for(var i = 0; i < arr.length; i++){
        //console.log('parseInt',parseInt(arr[i],16))
        val[i] = parseInt(arr[i],16)
    }
    //console.log('hex2str',val)
    return val
}
function addCss(filename){
	var creatHead = $('head');
	creatHead.append('<link rel="stylesheet" href="'+filename+'">')
}

function importJsFileIfMissing(jsUrl) {
	function checkJsFileIsImported(jsFileSrc) {
		return $(`script[src='${jsFileSrc}']`).length > 0;
	}
		console.log('importJsFileIfMissing init');
    if (!checkJsFileIsImported(jsUrl)) {
        let script = document.createElement("script");
        script.setAttribute("src", jsUrl);
        $('head').append(script);
		//homepage.init();
    }
}
// 移除css/js文件
function removejscssfile(filename,filetype){
	var targetelement=(filetype=="js")? "script" :(filetype=="css")? "link" : "none"
	var targetattr=(filetype=="js")?"src" : (filetype=="css")? "href" :"none"
	var allsuspects=document.getElementsByTagName(targetelement)
	for (var i=allsuspects.length; i>=0;i--){
		if (allsuspects[i] &&allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(filename)!=-1)
		allsuspects[i].parentNode.removeChild(allsuspects[i])
	}
}
/**
 * @msg: 
 * @param {number,string} hex 十进制数字或者字符
 * @param {string} len 位长度
 * @return {string} 返回十进制字符
 */
 function unsignedToReverse(hex,len){
    try{
      let bitArr;
      if(typeof hex === 'number'){
        bitArr = parseInt(hex);
      } else if(typeof hex === 'string'){
        bitArr = parseInt(hex,16);
      } else {
        console.error("hex参数有误")
        return;
      }
      bitArr = bitArr.toString(2).padStart(parseInt(len), "0").split('');
      let arr = [];
       console.log(bitArr)
      bitArr.map((item,index) => {
        if(item == 1){
          arr[index] = 0
        } else if(item == 0){
          arr[index] = 1
        }
      })
      console.log(bitArr)
      //return "0x" + parseInt(arr.join(''),2).toString(16);
      return parseInt(parseInt(arr.join(''),2).toString(10));
    } catch(err) {
      console.error("ERROR: %s",err)
    }
  }
  
 function getCurrentDate(){
  let date = new Date()
  let time=date.getHours().toString()+"时"+date.getMinutes().toString()+"分"+date.getSeconds().toString()+"秒"+date.getMilliseconds().toString()+'毫秒';
  return time;
 }
module.exports = {
    addCss: addCss,
    removejscssfile: removejscssfile,
    str2hex: str2hex,
    str2hexToDis: str2hexToDis,
    hex2array: hex2array,
    hex2strToDis: hex2strToDis,
    unsignedToReverse: unsignedToReverse,
    jsonToCSV: jsonToCSV,
    echartDataToLaypage: echartDataToLaypage,
    getCurrentDate: getCurrentDate,
}